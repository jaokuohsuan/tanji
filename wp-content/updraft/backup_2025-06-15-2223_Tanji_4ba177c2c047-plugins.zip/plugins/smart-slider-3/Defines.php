<?php

if (!defined('NEXTEND_SMARTSLIDER_3_URL_PATH')) {
    define('NEXTEND_SMARTSLIDER_3_URL_PATH', 'smart-slider3');
}

define('N2WORDPRESS', 1);
define('N2JOOMLA', 0);

define('N2GSAP', 0);
define('N2SSPRO', 0);